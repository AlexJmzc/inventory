<link rel="stylesheet" href="http://localhost/inventariohgpt/resources/css/footer.css">
<div class="fixed-footer">
  <p>© <?php
  echo date("Y"); 
      ?> H. Gobierno Provincial de Tungurahua</p>
</div>