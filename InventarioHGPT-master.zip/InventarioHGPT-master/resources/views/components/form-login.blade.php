<link rel="stylesheet" href="http://localhost/inventariohgpt/resources/css/formLogin.css">

<div class="container">

    <form id="signup">

        <div class="header">
        
            <h3>Iniciar Sesión</h3>
            
            <p>Sistema de Inventario</p>
            
        </div>
        
        <div class="sep"></div>

        <div class="inputs">
        
            <input type="email" placeholder="Usuario" autofocus />
        
            <input type="password" placeholder="Contraseña" />
                      
            <a id="submit" href="principal"> Ingresar </a>
        
        </div>

    </form>

</div>
