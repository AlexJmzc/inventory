

<link rel="stylesheet" href="http://localhost/inventariohgpt/resources/css/header.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.2/css/fontawesome.min.css" integrity="sha384-X8QTME3FCg1DLb58++lPvsjbQoCT9bp3MsUU3grbIny/3ZwUJkRNO8NPW6zqzuW9" crossorigin="anonymous">

<div class="general">
  <header>
        
        <a href="/a">
          <img src="http://localhost/inventariohgpt/resources/imagenes/LogoHGPT1.png" alt="" class="Logo">
        </a>
        <ul class="titulo">
        <a href="/principal">
          <img src="http://localhost/inventariohgpt/resources/imagenes/titulo.png" alt="" class="Logo">
        </a>
      </ul>
      <ul class="navegacion">
        <li><a href="/principal">Inicio</a></li>
      </ul>
  </header> 
</div>