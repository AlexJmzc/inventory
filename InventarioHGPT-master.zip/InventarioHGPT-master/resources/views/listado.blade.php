@extends('layouts.app')

@section('content')


<div class="d-flex justify-content-center">

    @livewire('tabla-equipos')

</div>

<x-footer></x-footer>
@endsection
